<?php

    $loader = new Twig_Loader_Filesystem('../APP/views/home');
    $twig = new Twig_Environment($loader);

 ?>
