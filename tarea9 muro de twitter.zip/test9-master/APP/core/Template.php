<?php

/**
 *
 */
class template
{
  static $instance;
  public function new_Template()
  {
    self::$instance = new Template;
  }
  function __construct()
  {

  }

function __destruct()
{

}

}


?>
