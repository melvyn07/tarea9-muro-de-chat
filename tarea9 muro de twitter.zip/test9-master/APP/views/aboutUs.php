<?php

echo "about us";
echo "<hr>";
echo "we are living";


 ?>
