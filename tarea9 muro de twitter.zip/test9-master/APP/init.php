<?php
//sesion start
session_start();

//Require thing's

// core
require_once 'core/APP.php';
require_once 'core/Controllers.php';
require_once 'core/Template.php';


// Models
require_once 'models/Conexion.php';
require_once 'models/userModel.php';

//controllers??
require_once 'controllers/usersController.php';

//Vars of page
define('APP_ROOT', 'http://localhost/test9/');
define('APP_Name', 'Umm???');

//vendor
require_once '../vendor/autoload.php';

//Scripts??


//CSS??


?>
