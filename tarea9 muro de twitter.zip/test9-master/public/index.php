<?php

require_once '../APP/init.php';

$app = new app();
 ?>
