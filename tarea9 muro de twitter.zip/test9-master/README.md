Test 9 post like a twitter
|Finished|
datebase test9 table users|comments|replies
